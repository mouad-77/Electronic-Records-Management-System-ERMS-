﻿namespace app_stage
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.b_Rechercher2 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.axAcroPDF1 = new AxAcroPDFLib.AxAcroPDF();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.b_Annuler = new System.Windows.Forms.Button();
            this.b_Imprimer = new System.Windows.Forms.Button();
            this.b_Suppremme = new System.Windows.Forms.Button();
            this.b_Ouvrir = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.axAcroPDF1)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.panel2, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel3, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.axAcroPDF1, 0, 1);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 17.76504F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 82.23495F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(643, 699);
            this.tableLayoutPanel1.TabIndex = 4;
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(3, 676);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(637, 20);
            this.panel2.TabIndex = 36;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(279, 1);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "Aperçu Pdf";
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.Controls.Add(this.b_Rechercher2);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.textBox1);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Location = new System.Drawing.Point(3, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(637, 113);
            this.panel3.TabIndex = 35;
            // 
            // b_Rechercher2
            // 
            this.b_Rechercher2.FlatAppearance.BorderSize = 0;
            this.b_Rechercher2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b_Rechercher2.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b_Rechercher2.ForeColor = System.Drawing.Color.Black;
            this.b_Rechercher2.Image = ((System.Drawing.Image)(resources.GetObject("b_Rechercher2.Image")));
            this.b_Rechercher2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.b_Rechercher2.Location = new System.Drawing.Point(433, 10);
            this.b_Rechercher2.Name = "b_Rechercher2";
            this.b_Rechercher2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.b_Rechercher2.Size = new System.Drawing.Size(201, 35);
            this.b_Rechercher2.TabIndex = 24;
            this.b_Rechercher2.Text = "     Rechercher";
            this.b_Rechercher2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.b_Rechercher2.UseVisualStyleBackColor = true;
            this.b_Rechercher2.Click += new System.EventHandler(this.b_Rechercher2_Click_1);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(3, 15);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(242, 25);
            this.label4.TabIndex = 23;
            this.label4.Text = "Rechercher par le  N° :";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(251, 12);
            this.textBox1.MaxLength = 100000;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(174, 33);
            this.textBox1.TabIndex = 18;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(51, 69);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(75, 25);
            this.label3.TabIndex = 22;
            this.label3.Text = "label3";
            // 
            // axAcroPDF1
            // 
            this.axAcroPDF1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.axAcroPDF1.Enabled = true;
            this.axAcroPDF1.Location = new System.Drawing.Point(3, 122);
            this.axAcroPDF1.Name = "axAcroPDF1";
            this.axAcroPDF1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axAcroPDF1.OcxState")));
            this.axAcroPDF1.Size = new System.Drawing.Size(637, 548);
            this.axAcroPDF1.TabIndex = 37;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.panel1, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.panel4, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.pictureBox1, 0, 1);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(652, 0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 3;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 18.41317F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 81.58683F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(424, 695);
            this.tableLayoutPanel2.TabIndex = 3;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.b_Annuler);
            this.panel1.Controls.Add(this.b_Imprimer);
            this.panel1.Controls.Add(this.b_Suppremme);
            this.panel1.Controls.Add(this.b_Ouvrir);
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(418, 117);
            this.panel1.TabIndex = 1;
            // 
            // b_Annuler
            // 
            this.b_Annuler.FlatAppearance.BorderSize = 0;
            this.b_Annuler.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b_Annuler.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b_Annuler.ForeColor = System.Drawing.Color.Black;
            this.b_Annuler.Image = ((System.Drawing.Image)(resources.GetObject("b_Annuler.Image")));
            this.b_Annuler.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.b_Annuler.Location = new System.Drawing.Point(199, 59);
            this.b_Annuler.Name = "b_Annuler";
            this.b_Annuler.Size = new System.Drawing.Size(219, 54);
            this.b_Annuler.TabIndex = 10;
            this.b_Annuler.Text = "       Annuler ";
            this.b_Annuler.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.b_Annuler.UseVisualStyleBackColor = true;
            this.b_Annuler.Click += new System.EventHandler(this.b_Annuler_Click_1);
            // 
            // b_Imprimer
            // 
            this.b_Imprimer.FlatAppearance.BorderSize = 0;
            this.b_Imprimer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b_Imprimer.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b_Imprimer.ForeColor = System.Drawing.Color.Black;
            this.b_Imprimer.Image = ((System.Drawing.Image)(resources.GetObject("b_Imprimer.Image")));
            this.b_Imprimer.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.b_Imprimer.Location = new System.Drawing.Point(3, 60);
            this.b_Imprimer.Name = "b_Imprimer";
            this.b_Imprimer.Size = new System.Drawing.Size(190, 54);
            this.b_Imprimer.TabIndex = 9;
            this.b_Imprimer.Text = "      Imprimer";
            this.b_Imprimer.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.b_Imprimer.UseVisualStyleBackColor = true;
            this.b_Imprimer.Click += new System.EventHandler(this.b_Imprimer_Click_1);
            // 
            // b_Suppremme
            // 
            this.b_Suppremme.FlatAppearance.BorderSize = 0;
            this.b_Suppremme.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b_Suppremme.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b_Suppremme.ForeColor = System.Drawing.Color.Black;
            this.b_Suppremme.Image = ((System.Drawing.Image)(resources.GetObject("b_Suppremme.Image")));
            this.b_Suppremme.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.b_Suppremme.Location = new System.Drawing.Point(199, 5);
            this.b_Suppremme.Name = "b_Suppremme";
            this.b_Suppremme.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.b_Suppremme.Size = new System.Drawing.Size(219, 54);
            this.b_Suppremme.TabIndex = 8;
            this.b_Suppremme.Text = "       Suppremme ";
            this.b_Suppremme.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.b_Suppremme.UseVisualStyleBackColor = true;
            this.b_Suppremme.Click += new System.EventHandler(this.b_Suppremme_Click_1);
            // 
            // b_Ouvrir
            // 
            this.b_Ouvrir.FlatAppearance.BorderSize = 0;
            this.b_Ouvrir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b_Ouvrir.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b_Ouvrir.ForeColor = System.Drawing.Color.Black;
            this.b_Ouvrir.Image = ((System.Drawing.Image)(resources.GetObject("b_Ouvrir.Image")));
            this.b_Ouvrir.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.b_Ouvrir.Location = new System.Drawing.Point(3, 8);
            this.b_Ouvrir.Name = "b_Ouvrir";
            this.b_Ouvrir.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.b_Ouvrir.Size = new System.Drawing.Size(190, 54);
            this.b_Ouvrir.TabIndex = 7;
            this.b_Ouvrir.Text = "      Ouvrir avec";
            this.b_Ouvrir.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.b_Ouvrir.UseVisualStyleBackColor = true;
            this.b_Ouvrir.Click += new System.EventHandler(this.b_Ouvrir_Click_1);
            // 
            // panel4
            // 
            this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel4.Controls.Add(this.label2);
            this.panel4.Location = new System.Drawing.Point(3, 671);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(418, 21);
            this.panel4.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(157, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(115, 18);
            this.label2.TabIndex = 0;
            this.label2.Text = "Aperçu Image";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.Location = new System.Drawing.Point(3, 126);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(418, 539);
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1079, 699);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.tableLayoutPanel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form3";
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.axAcroPDF1)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button b_Rechercher2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button b_Annuler;
        private System.Windows.Forms.Button b_Imprimer;
        private System.Windows.Forms.Button b_Suppremme;
        private System.Windows.Forms.Button b_Ouvrir;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
        public AxAcroPDFLib.AxAcroPDF axAcroPDF1;
    }
}