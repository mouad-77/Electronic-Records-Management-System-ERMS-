﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Configuration;

namespace app_stage
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
        }
        SqlConnection con = new SqlConnection("Data Source=Localhost\\SQLExpress; Integrated Security=SSPI; Initial Catalog=PROJETDESTAGGGE");
        DataTable t = new DataTable();
        string path;

    

        private void b_parcourir_Click_1(object sender, EventArgs e)
        {
            DialogResult dialoge = openFileDialog1.ShowDialog();
            openFileDialog1.Filter = "Excell|*.xls;*.xlsx;";
            if (dialoge == DialogResult.OK)
            {
                string fileName = openFileDialog1.FileName;
                textBox1.Text = fileName;
            }
        }

        private void b_Mise_Click_1(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text == "" && textBox2.Text == "")
                {

                    MessageBox.Show("Remplir les champs");
                }
                else
                {
                    path = textBox1.Text;
                    string ConStr = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"Excel 12.0;HDR=Yes;IMEX=1\"";
                    OleDbConnection Excel = new OleDbConnection(ConStr);
                    Excel.Open();
                    OleDbCommand cmd = new OleDbCommand("Select * From ["+textBox2.Text+"$]", Excel);
                    OleDbDataReader dr = cmd.ExecuteReader();
                    t.Load(dr);
                    Excel.Close();
                    MessageBox.Show(" Bien Importer les données");
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void b_base_Click_1(object sender, EventArgs e)
        {
              try
            {
                if (textBox1.Text == "" && textBox2.Text == "")
                {
                    MessageBox.Show("Remplir les champs");
                }
                else
                {

                    if (MessageBox.Show("pour ajouter les données il faut dabour supprimer les donner exist ,Vouier vous ajouter ?", "importon", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        suprimer();
                        Ajouter();
                    }
                }

                textBox1.Text = "";
                textBox2.Text = "";
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
        private void suprimer()
        {
            con.Open();
            SqlCommand CM = new SqlCommand("delete from LOGINt", con);
            CM.ExecuteNonQuery();
            con.Close();
        }

        private void Ajouter()
        {
            con.Open();
            SqlBulkCopy copy = new SqlBulkCopy(con);
            copy.DestinationTableName = "LOGINt";
            copy.WriteToServer(t);
            con.Close();
            MessageBox.Show(" Bien  Mise à jour a la base");
            con.Close();
        }

    }
}
