﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace app_stage
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection("Data Source=Localhost\\SQLExpress; Integrated Security=SSPI; Initial Catalog=PROJETDESTAGGGE");
       

        private void b_Mise_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void b_base_Click_1(object sender, EventArgs e)
        {
            try
            {
                if (tex_nom.Text == "" && text_mot.Text == "" && text_nouvMot.Text == "" && text_confirm.Text == "")
                {
                    MessageBox.Show("Remplir les champs");
                }
                else
                {

                    if (MessageBox.Show("pour ajouter les données il faut dabour supprimer les donner exist ,Vouier vous ajouter ?", "importon", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        con.Open();
                        string username = tex_nom.Text;
                        string password = text_mot.Text;
                        string newPassword = text_nouvMot.Text;
                        string confirmPassword = text_confirm.Text;
                        string sqlquery = "UPDATE [LOGINTOAPP] SET Passwordd=@newpass where  UserName=@username"; SqlCommand cmd = new SqlCommand(sqlquery, con); cmd.Parameters.AddWithValue("@newpass", text_nouvMot.Text); cmd.Parameters.AddWithValue("@username", tex_nom.Text); cmd.Parameters.AddWithValue("@password", text_mot.Text);
                        cmd.Connection = con;
                        cmd.ExecuteNonQuery();
                        SqlDataReader reader = null;
                        reader = cmd.ExecuteReader();
                        while (reader.Read())
                        {
                            if ((text_nouvMot.Text == reader["newPassword"].ToString()) && (text_confirm.Text == (reader["confirmPassword"].ToString()))) { } else { MessageBox.Show(""); }
                        }
                        MessageBox.Show("Password Changed Successfully!");
                        text_nouvMot.Text = "";
                        text_confirm.Text = "";
                        tex_nom.Text = "";
                        text_mot.Text = "";



                    }
                    else
                    {
                        MessageBox.Show("Password Changed Successfully!");
                        text_nouvMot.Text = "";
                        text_confirm.Text = "";
                        tex_nom.Text = "";
                        text_mot.Text = "";
                    }
                }

            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }

        }
    }
}
