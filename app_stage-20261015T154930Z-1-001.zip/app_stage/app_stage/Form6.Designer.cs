﻿namespace app_stage
{
    partial class Form6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form6));
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.text_confirm = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.text_nouvMot = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.text_mot = new System.Windows.Forms.TextBox();
            this.b_base = new System.Windows.Forms.Button();
            this.b_Mise = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tex_nom = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(126, 85);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(814, 63);
            this.tableLayoutPanel1.TabIndex = 4;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(808, 57);
            this.panel1.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(167, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(450, 38);
            this.label2.TabIndex = 0;
            this.label2.Text = "Mise à jour la ( Connexion ) ";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.panel2, 0, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(126, 243);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(814, 342);
            this.tableLayoutPanel2.TabIndex = 5;
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.text_confirm);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.text_nouvMot);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.text_mot);
            this.panel2.Controls.Add(this.b_base);
            this.panel2.Controls.Add(this.b_Mise);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.tex_nom);
            this.panel2.Location = new System.Drawing.Point(3, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(808, 336);
            this.panel2.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(94, 185);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(391, 25);
            this.label4.TabIndex = 33;
            this.label4.Text = "Confirmez le nouveau mot de passe :";
            // 
            // text_confirm
            // 
            this.text_confirm.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_confirm.Location = new System.Drawing.Point(491, 182);
            this.text_confirm.Name = "text_confirm";
            this.text_confirm.Size = new System.Drawing.Size(216, 33);
            this.text_confirm.TabIndex = 32;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(94, 140);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(286, 25);
            this.label5.TabIndex = 31;
            this.label5.Text = "Le nouveau mot de passe :";
            // 
            // text_nouvMot
            // 
            this.text_nouvMot.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_nouvMot.Location = new System.Drawing.Point(491, 137);
            this.text_nouvMot.Name = "text_nouvMot";
            this.text_nouvMot.Size = new System.Drawing.Size(216, 33);
            this.text_nouvMot.TabIndex = 30;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(94, 90);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(160, 25);
            this.label3.TabIndex = 29;
            this.label3.Text = "Mot de passe :";
            // 
            // text_mot
            // 
            this.text_mot.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_mot.Location = new System.Drawing.Point(491, 87);
            this.text_mot.Name = "text_mot";
            this.text_mot.Size = new System.Drawing.Size(216, 33);
            this.text_mot.TabIndex = 28;
            // 
            // b_base
            // 
            this.b_base.FlatAppearance.BorderSize = 0;
            this.b_base.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b_base.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b_base.ForeColor = System.Drawing.Color.Black;
            this.b_base.Image = ((System.Drawing.Image)(resources.GetObject("b_base.Image")));
            this.b_base.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.b_base.Location = new System.Drawing.Point(559, 257);
            this.b_base.Name = "b_base";
            this.b_base.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.b_base.Size = new System.Drawing.Size(216, 45);
            this.b_base.TabIndex = 26;
            this.b_base.Text = "     Mise à jour ";
            this.b_base.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.b_base.UseVisualStyleBackColor = true;
            this.b_base.Click += new System.EventHandler(this.b_base_Click_1);
            // 
            // b_Mise
            // 
            this.b_Mise.FlatAppearance.BorderSize = 0;
            this.b_Mise.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b_Mise.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b_Mise.ForeColor = System.Drawing.Color.Black;
            this.b_Mise.Image = ((System.Drawing.Image)(resources.GetObject("b_Mise.Image")));
            this.b_Mise.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.b_Mise.Location = new System.Drawing.Point(20, 257);
            this.b_Mise.Name = "b_Mise";
            this.b_Mise.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.b_Mise.Size = new System.Drawing.Size(222, 45);
            this.b_Mise.TabIndex = 25;
            this.b_Mise.Text = "     Annuler";
            this.b_Mise.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.b_Mise.UseVisualStyleBackColor = true;
            this.b_Mise.Click += new System.EventHandler(this.b_Mise_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(94, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(194, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "Nom d\'utilisateur :";
            // 
            // tex_nom
            // 
            this.tex_nom.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tex_nom.Location = new System.Drawing.Point(491, 37);
            this.tex_nom.Name = "tex_nom";
            this.tex_nom.Size = new System.Drawing.Size(216, 33);
            this.tex_nom.TabIndex = 0;
            // 
            // Form6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1063, 661);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.tableLayoutPanel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form6";
            this.Text = "Form6";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox text_mot;
        private System.Windows.Forms.Button b_base;
        private System.Windows.Forms.Button b_Mise;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tex_nom;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox text_confirm;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox text_nouvMot;
    }
}