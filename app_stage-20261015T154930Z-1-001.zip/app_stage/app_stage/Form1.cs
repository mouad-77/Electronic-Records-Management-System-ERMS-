﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace app_stage
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            Form_in_Panel(new Form2());
            panel6.Visible = false;
            SidePanel.Height = b_Accueil.Height;
            SidePanel.Top = b_Accueil.Top;
        }
        private void Form_in_Panel(object FormP)
        {
            if (this.Pcontainer.Controls.Count > 0)
                this.Pcontainer.Controls.RemoveAt(0);
            Form fh = FormP as Form;
            fh.TopLevel = false;
            fh.Dock = DockStyle.Fill;
            this.Pcontainer.Controls.Add(fh);
            this.Pcontainer.Tag = fh;
            fh.Show();
        }

        private void b_Accueil_Click(object sender, EventArgs e)
        {
            SidePanel.Height = b_Accueil.Height;
            SidePanel.Top = b_Accueil.Top;
            Form_in_Panel(new Form2());
        }

        private void b_Rechercher_Click(object sender, EventArgs e)
        {

            SidePanel.Height = b_Rechercher.Height;
            SidePanel.Top = b_Rechercher.Top;
            Form_in_Panel(new Form3());
        }

        private void b_Ajouter_Click(object sender, EventArgs e)
        {
            SidePanel.Height = b_Ajouter.Height;
            SidePanel.Top = b_Ajouter.Top;
            Form_in_Panel(new Form4());
        }

        private void b_Mise_Click(object sender, EventArgs e)
        {

            SidePanel.Height = b_Mise.Height;
            SidePanel.Top = b_Mise.Top;
            Form_in_Panel(new Form5());
        }

      
        private void login_Click(object sender, EventArgs e)
        {
            SidePanel.Height = login.Height;
            SidePanel.Top = login.Top;
            Form_in_Panel(new Form6());
        }

       
        private void b_Exit_Click(object sender, EventArgs e)
        {

            SidePanel.Height = b_Exit.Height;
            SidePanel.Top = b_Exit.Top;
            if (MessageBox.Show("Vous vous Exit l'application ?", "importon", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

       

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            if (panel1.Width == 219)
            {
                panel1.Width = 65;
                panel5.Visible = false;
                panel6.Visible = true;
            }
            else
            {
                panel1.Width = 219;
                panel5.Visible = true;
                panel6.Visible = false;
            }
        }

        

       
    }
}
