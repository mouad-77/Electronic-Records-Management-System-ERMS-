﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace app_stage
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection("Data Source=Localhost\\SQLExpress; Integrated Security=SSPI; Initial Catalog=PROJETDESTAGGGE"); // making connection   
        Form1 f = new Form1();
        private void login_Load(object sender, EventArgs e)
        {

        }
        
        
        private void b_Connecte_Click(object sender, EventArgs e)
        {
            
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from LOGINTOAPP where UserName='" + TextBox1.Text + "' AND Passwordd ='" + TextBox2.Text + "' ", con);
            SqlDataReader der = cmd.ExecuteReader();
            if (der.Read())
            {
                this.Hide();
                f.Show();

               // MessageBox.Show("bien");

            }
            else
            {

                lblError.Text = "Le Nom d'utilisateur ou Mot de Passe et Invalid";
                TextBox1.Text = "";
                TextBox2.Text = "";
            }
            der.Close();
            con.Close();
        
    }

        private void Fermer_Click(object sender, EventArgs e)
        {
            this.Close();
        }
       

    
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                TextBox2.UseSystemPasswordChar = true;
                labelpwd.Text = "Cacher Mot de passe";
            }
            else
            {
                TextBox2.UseSystemPasswordChar = false;
                labelpwd.Text = "Afficher Mot de passe";
            }
        }
    }
}
