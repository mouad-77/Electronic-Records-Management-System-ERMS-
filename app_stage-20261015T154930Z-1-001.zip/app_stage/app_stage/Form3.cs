﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using PdfSharp;
using PdfSharp.Pdf;
using PdfSharp.Drawing;
using System.IO;
using System.Diagnostics;

namespace app_stage
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
      

        private void Form3_Load(object sender, EventArgs e)
        {
            label3.Text = "";
            textBox1.Text = "";
            pictureBox1.Image = null;
            axAcroPDF1 = null;
            FillPDF = null;
            SqlDataAdapter da = new SqlDataAdapter("select * from fff$", con);
        }
        SqlConnection con = new SqlConnection("Data Source=Localhost\\SQLExpress; Integrated Security=SSPI; Initial Catalog=PROJETDESTAGGGE");
        string FillPDF;
       
        private void b_Rechercher2_Click_1(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text == "")
                {
                    label3.Text = "entre votre valeur";

                }
                else
                {
                    if (con.State != ConnectionState.Open)
                        con.Open();
                    SqlCommand cmd = new SqlCommand("SELECT * FROM fille WHERE ID like '%" + textBox1.Text.Replace("'", "''") + "%'", con);
                    //or CIN like '%" + textBox1.Text.Replace("'", "''") + " % '"
                    SqlDataReader dr = null;
                    dr = cmd.ExecuteReader();
                    dr.Read();
                    if (dr.HasRows)
                    {
                        label3.Text = "";
                        label3.Text = "Ce N° " + dr[0].ToString() + "  et existe dons la base de donnée ";
                        label3.Text = dr[0].ToString();
                        //img
                        Byte[] img = (Byte[])(dr[2]);
                        if (img == null)
                            pictureBox1.Image = null;
                        else
                        {
                            MemoryStream ms = new MemoryStream(img);
                            pictureBox1.Image = Image.FromStream(ms);
                        }
                        // pdf

                        Byte[] pdf = (Byte[])(dr[1]);
                        if (img == null)
                            MessageBox.Show("L'aperçu Pdf Né Trouve Pas   ");
                        else
                        {
                            string FillPDF = dr[1].ToString();
                            FileStream fs = new FileStream(FillPDF, FileMode.OpenOrCreate, FileAccess.Read);
                            fs.Write(pdf, 0, pdf.Length);
                            fs.Close();
                            axAcroPDF1.LoadFile(FillPDF);
                        }
                    }
                    else
                    {
                        label3.Text = "";
                        label3.Text = "Ce N° " + textBox1.Text + "  n'existe pas ";
                        textBox1.Text = "";
                        pictureBox1.Image = null;
                    }
                    con.Close();
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }

        }

        private void b_Ouvrir_Click_1(object sender, EventArgs e)
        {

            try
            {
                if (textBox1.Text == "")
                {
                    label3.Text = "entre votre valeur";

                }
                else
                {

                    Process.Start(FillPDF);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void b_Suppremme_Click_1(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text != "" && pictureBox1.Image != null)
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("delete from fille WHERE ID like '%" + textBox1.Text.Replace("'", "''") + "%'", con);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("La Suppression Et Bien Fait");
                    label3.Text = "";
                    textBox1.Text = "";
                    pictureBox1.Image = null;
                }
                else
                {
                    MessageBox.Show("La Suppression Né Pas Bien Fait  ");
                    label3.Text = "";
                    textBox1.Text = "";
                    pictureBox1.Image = null;

                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void b_Imprimer_Click_1(object sender, EventArgs e)
        {
            if (axAcroPDF1 == null)
            {
                MessageBox.Show("La Imprimer Né Pas Bien Fait  ");
            }
            else

                axAcroPDF1.printWithDialog();
        }


        private void b_Annuler_Click_1(object sender, EventArgs e)
        {
            label3.Text = "";
            textBox1.Text = "";
            pictureBox1.Image = null;
            axAcroPDF1 = null;
        }
    }
}
