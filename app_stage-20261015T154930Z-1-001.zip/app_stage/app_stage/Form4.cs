﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WIA;
using System.Runtime.InteropServices;
using System.IO;
using System.Data.SqlClient;
using PdfSharp.Pdf;
using PdfSharp.Drawing;
namespace app_stage
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
           
        }
        SqlConnection con = new SqlConnection("Data Source=Localhost\\SQLExpress; Integrated Security=SSPI; Initial Catalog=PROJETDESTAGGGE");
        int s = 0;
        string Path;
        string PathX;
        PdfDocument doc = new PdfDocument();

        private void Form4_Load(object sender, EventArgs e)
        {
            label3.Text = "";

            SqlDataAdapter da = new SqlDataAdapter("select * from fff$", con);

            try
            {
                var deviceManager = new DeviceManager();
                for (int i = 1; i <= deviceManager.DeviceInfos.Count; i++)
                {
                    if (deviceManager.DeviceInfos[i].Type != WiaDeviceType.ScannerDeviceType)
                    {
                        continue;
                    }
                    listBox1.Items.Add(deviceManager.DeviceInfos[i].Properties["Name"].get_Value());
                }

            }
            catch (COMException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        
        
   
        private void b_Scanner_Click_1(object sender, EventArgs e)
        {
            try
            {
                var deviceManager = new DeviceManager();
                DeviceInfo AvailableScanner = null;

                for (int i = 1; i <= deviceManager.DeviceInfos.Count; i++) // Loop Through the get List Of Devices.
                {
                    if (deviceManager.DeviceInfos[i].Type != WiaDeviceType.ScannerDeviceType) // Skip device If it is not a scanner
                    {
                        continue;
                    }

                    AvailableScanner = deviceManager.DeviceInfos[i];

                    break;
                }
                // if ()
                var device = AvailableScanner.Connect(); //Connect to the available scanner.

                var ScanerItem = device.Items[1]; // select the scanner.

                var imgFile = (ImageFile)ScanerItem.Transfer(FormatID.wiaFormatJPEG); //Retrive an image in Jpg format and store it into a variable.



                Path = @"E:\ScanImg" + s.ToString() + ".jpg"; // save the image in some path with filename.
                if (File.Exists(Path))
                {
                    File.Delete(Path);
                }
                imgFile.SaveFile(Path);

                PathX = @"E:\ScanImg" + 0.ToString() + ".jpg";
                pictureBox1.ImageLocation = PathX;
                s++;

            }
            catch (COMException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void Convertir()
        {

            try
            {

                string destinaton = textBox1.Text;
                doc.Pages.Add(new PdfPage());
                XGraphics xgr = XGraphics.FromPdfPage(doc.Pages[0]);
                XImage img = XImage.FromFile(Path);
                xgr.DrawImage(img, 0, 0);
                doc.Save(destinaton);
                doc.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void b_Enregistrer_Click_1(object sender, EventArgs e)
        {
            Convertir();

            try
            {
                Byte[] pdf = null;
                FileStream fs = new FileStream(doc.FullPath, FileMode.Open, FileAccess.Read);
                BinaryReader br = new BinaryReader(fs);
                pdf = br.ReadBytes((int)fs.Length);
                fs.Close();

                Byte[] img = null;
                FileStream fm = new FileStream(PathX, FileMode.Open);
                BinaryReader bm = new BinaryReader(fm);
                img = bm.ReadBytes((int)fm.Length);
                fm.Close();

                con.Open();
                SqlCommand cmd = new SqlCommand("insert into fille (ID,imagee,puct)values(" + textBox1.Text + ",@img,@pdf)", con);
                cmd.Parameters.Add(new SqlParameter("@pdf", pdf));
                cmd.Parameters.Add(new SqlParameter("@img", img));
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("bien ajouter");
                label3.Text = "";
                textBox1.Text = "";
                pictureBox1.Image = null;
                Path = "";
                PathX = "";
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void b_Rechercher_Click_1(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                label3.Text = "entre votre valeur";

            }
            else
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM LOGINt WHERE ID like '%" + textBox1.Text.Replace("'", "''") + "%' or CIN like '%" + textBox1.Text.Replace("'", "''") + "%'", con);
                SqlDataReader dr = null;
                dr = cmd.ExecuteReader();
                if (dr.Read() == true)
                {

                    label3.Text = "Ce N° " + textBox1.Text + "  Et existe dons la base de donnée ";

                }
                else
                {

                    label3.Text = "Ce N° " + textBox1.Text + "  N'existe pas ";
                }

                con.Close();

            }
        }
    }
}
