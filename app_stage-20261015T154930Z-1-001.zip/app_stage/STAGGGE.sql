CREATE DATABASE PROJETDESTAGGGE
USE PROJETDESTAGGGE
--------  Create des tables  ---------
            
          Create table Excel
           (
           ID int primary key,
           CIN varchar(50),
		   NOM Varchar(50)
		   )
            
		   create table fille
		   (
		   ID int foreign key references  Excel(ID) ,
		   imagee varbinary(max),
		   puct image 
		   )

           Create table LOGINTOAPP
           (
           UserName varchar(50),
		   Passwordd Varchar(50)
		   )
		   INSERT INTO LOGINTOAPP VALUES('admin','ad123')
		   
		   
		   select * from fille
		   select * from Excel
		   select * from LOGINTOAPP